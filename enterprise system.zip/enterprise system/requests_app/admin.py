from datetime import timedelta

from django.contrib import admin
from django.utils import timezone

from .models import Category, Comment, ServiceRequest, WorkOrder


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "is_active", "created_at")
    list_filter = ("is_active",)
    search_fields = ("name", "description")


class OverdueFilter(admin.SimpleListFilter):
    title = "overdue status"
    parameter_name = "overdue"

    def lookups(self, request, model_admin):
        return [
            ("overdue", "Overdue (not finished, past due date)"),
            ("next24", "Due in the next 24 hours"),
            ("nodue", "No due date"),
        ]

    def queryset(self, request, queryset):
        now = timezone.now()
        unfinished = ["open", "assigned", "in_progress"]
        if self.value() == "overdue":
            return queryset.filter(status__in=unfinished, due_at__lt=now)
        if self.value() == "next24":
            return queryset.filter(
                status__in=unfinished,
                due_at__gte=now,
                due_at__lte=now + timedelta(hours=24),
            )
        if self.value() == "nodue":
            return queryset.filter(due_at__isnull=True)
        return queryset


class CommentInline(admin.TabularInline):
    model = Comment
    extra = 0
    fields = ("author", "body", "is_internal", "created_at")
    readonly_fields = ("created_at",)


@admin.register(ServiceRequest)
class ServiceRequestAdmin(admin.ModelAdmin):
    list_display = (
        "title", "category", "requester", "priority", "status",
        "due_at", "resolved_at", "short_summary", "created_at",
    )
    list_filter = ("status", "priority", "category", OverdueFilter)
    search_fields = (
        "title", "description", "location",
        "requester__username", "resolution_summary",
    )
    readonly_fields = ("id", "created_at", "updated_at")
    autocomplete_fields = ("requester", "category")
    date_hierarchy = "created_at"
    inlines = (CommentInline,)

    @admin.display(description="Resolution summary")
    def short_summary(self, obj):
        text = obj.resolution_summary or ""
        return text if len(text) <= 40 else text[:40] + "..."


@admin.register(WorkOrder)
class WorkOrderAdmin(admin.ModelAdmin):
    list_display = ("service_request", "technician", "started_at", "completed_at")
    search_fields = ("service_request__title", "technician__username")
    autocomplete_fields = ("service_request", "technician")


@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ("service_request", "author", "is_internal", "created_at")
    list_filter = ("is_internal", "created_at")
    search_fields = ("body", "service_request__title", "author__username")